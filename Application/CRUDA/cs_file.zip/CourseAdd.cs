﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace CRUDA
{
    public partial class CourseAdd : Form
    {
        bool x = false;
        string name;
        string code;
        public CourseAdd()
        {
            InitializeComponent();
        }

        public CourseAdd(bool x,string name,string code)
        {
            InitializeComponent();
            this.x = x;
            this.name = name;
            this.code = code;
        }
        private void CourseAdd_Load(object sender, EventArgs e)
        {
            if (this.x == true)
            {
                ADD.Text = "Update";
                Nametxt.Text = name;
                Codetxt.Text = code;

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ADD_Click(object sender, EventArgs e)
        {
            if (x == false)
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Course values ( @Name,@Code)", con);
                cmd.Parameters.AddWithValue("@Name", Nametxt.Text);
                cmd.Parameters.AddWithValue("@Code", Codetxt.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Added");
            }
            else 
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd2 = new SqlCommand("Update Course Set Name=@Cname,Code=@Ccode WHERE Code=@ID", con2);
                //cmd2.Parameters.AddWithValue("@Session", int.Parse(Sessiontxt.Text));
                cmd2.Parameters.AddWithValue("@ID", code);
                cmd2.Parameters.AddWithValue("@Cname", Nametxt.Text);
                cmd2.Parameters.AddWithValue("@Ccode", Codetxt.Text);
                cmd2.ExecuteNonQuery();
                MessageBox.Show("Successfully update");

            }
        }
    }
}
