﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUDA
{
    public partial class View_Enrollments : Form
    {
        public View_Enrollments()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Enrollments", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.ColumnIndex;
            int rowInd = dataGridView1.CurrentCell.RowIndex;
            string code = (dataGridView1.Rows[rowInd].Cells[1].Value.ToString());
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Delete FROM Enrollments  where CourseName= @RegistrationNo", con);
            cmd.Parameters.AddWithValue("@RegistrationNo", code);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully deleted");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form a = new Add_Enrollments();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.ColumnIndex;
            int rowInd = dataGridView1.CurrentCell.RowIndex;
            string code = (dataGridView1.Rows[rowInd].Cells[1].Value.ToString());
            string x = (dataGridView1.Rows[rowInd].Cells[0].Value.ToString());
            Form g = new Add_Enrollments(true, x, code);
            g.Show();

        }
    }
}
