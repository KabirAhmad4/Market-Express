﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUDA
{
    public partial class View_Students : Form
    {
        public View_Students()
        {
            InitializeComponent();
        }
        //string reg,string name,string dep,string address,int session
        private void button2_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.ColumnIndex;
            int rowInd = dataGridView1.CurrentCell.RowIndex;
            string Registerationt = (dataGridView1.Rows[rowInd].Cells[0].Value.ToString());
            string name = (dataGridView1.Rows[rowInd].Cells[1].Value.ToString());
            string address = (dataGridView1.Rows[rowInd].Cells[4].Value.ToString());
            string dep = (dataGridView1.Rows[rowInd].Cells[2].Value.ToString());
            int session = int.Parse((dataGridView1.Rows[rowInd].Cells[3].Value.ToString()));
            Form open = new AddStudentForm(true,Registerationt,name,dep,address,session);
            open.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        //[RegisterationNumber]
      //,[Name]
      //,[Department]
      //,[Session]
      //,[Address]

        private void button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.ColumnIndex;
            int rowInd = dataGridView1.CurrentCell.RowIndex;
            string Registerationt = (dataGridView1.Rows[rowInd].Cells[0].Value.ToString());
            string address = (dataGridView1.Rows[rowInd].Cells[4].Value.ToString());
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Delete FROM Student  where RegisterationNumber= @RegistrationNo",con);
            cmd.Parameters.AddWithValue("@RegistrationNo", Registerationt);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully deleted");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form  Add= new AddStudentForm();
            Add.Show();
        }
    }
}
