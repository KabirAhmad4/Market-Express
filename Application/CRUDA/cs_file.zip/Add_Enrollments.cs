﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CRUDA
{
    public partial class Add_Enrollments : Form
    {
        bool x = false;
        string s;
        string c;
        public Add_Enrollments()
        {
            InitializeComponent();
        }
        public Add_Enrollments(bool x,string c,string s)
        {
            InitializeComponent();
            this.x = x;
            this.c = c;
            this.s = s; 
        }
        public void check()
        {
            var con2 = Configuration.getInstance().getConnection();
            SqlCommand cmd2 = new SqlCommand("Select RegisterationNumber, Code from Student,Course", con2);
            SqlDataReader dr2;
            dr2 = cmd2.ExecuteReader();
           // int i = 0;
            while (dr2.Read())
            {
                Coursetxt.Items.Add(dr2[1]).ToString();
                if (!Nametxt.Items.Contains(dr2[0])) { Nametxt.Items.Add(dr2[0]).ToString(); }
            }
            dr2.Close();
        }

        private void Add_Enrollments_Load(object sender, EventArgs e)
        {

            Nametxt.Text = s;Coursetxt.Text = c;
            if (x) { button2.Text = "Update"; }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            check();
        }

        private void button2_Click(object sender, EventArgs e)

        {
            if (this.x == true)
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd2 = new SqlCommand("Update Enrollments Set StudentRegNo=@Name,CourseName=@Department WHERE CourseName=@ID AND StudentRegNo=@xi", con2);

                cmd2.Parameters.AddWithValue("@ID", c);
                cmd2.Parameters.AddWithValue("@xi", s);
                cmd2.Parameters.AddWithValue("@Name", Nametxt.Text);
                cmd2.Parameters.AddWithValue("@Department", Coursetxt.Text);

                cmd2.ExecuteNonQuery();
                MessageBox.Show("Successfully update");
            }
            else
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Enrollments values ( @RegisterationNo,@Name)", con);

                cmd.Parameters.AddWithValue("@Name",    Nametxt.Text);
                cmd.Parameters.AddWithValue("@RegisterationNo", Coursetxt.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Added");

            }
        }
    }
}
