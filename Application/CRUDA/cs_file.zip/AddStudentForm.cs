﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CRUDA
{
    public partial class AddStudentForm : Form
    {
        public bool x=false;
        //@RegisterationNo,@Name,@Department,@Session,@Address
        public string reg;
        public string name;
        public string dep;
        public string address;
        public int session;

        public AddStudentForm(bool x, string reg,string name,string dep,string address,int session)
        {
            InitializeComponent();
            this.x = x;
            this.reg = reg;
            this.name = name;   
            this.dep = dep; 
            this.address = address;
            this.session = session;
        }
        public AddStudentForm()
        {
            InitializeComponent();

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (this.x == true)
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd2 = new SqlCommand("Update Student Set RegisterationNumber=@RegisterationNo,NAME=@Name,Department=@Department,Session=@Session,Address=@Address WHERE RegisterationNumber=@ID", con2);
                cmd2.Parameters.AddWithValue("@Session", int.Parse(Sessiontxt.Text));
                cmd2.Parameters.AddWithValue("@ID", reg);
                cmd2.Parameters.AddWithValue("@Name", nameboxtxt.Text);
                cmd2.Parameters.AddWithValue("@Department", Departmenttxt.Text);
                cmd2.Parameters.AddWithValue("@RegisterationNo", RegisteratioNotxt.Text);
                cmd2.Parameters.AddWithValue("@Address", Adresstxt.Text);
                cmd2.ExecuteNonQuery();
                MessageBox.Show("Successfully update");
            }
            else
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into Student values ( @RegisterationNo,@Name,@Department,@Session,@Address)", con);
                cmd.Parameters.AddWithValue("@Session", int.Parse(Sessiontxt.Text));
                cmd.Parameters.AddWithValue("@Name", nameboxtxt.Text);
                cmd.Parameters.AddWithValue("@Department", Departmenttxt.Text);
                cmd.Parameters.AddWithValue("@RegisterationNo", RegisteratioNotxt.Text);
                cmd.Parameters.AddWithValue("@Address", Adresstxt.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Added");

            }

        }

        private void AddStudentForm_Load(object sender, EventArgs e)
        {
            if (this.x == true) 
            {
                Addbtn.Text = "Update";
                nameboxtxt.Text = name;
                Departmenttxt.Text = dep;
                Sessiontxt.Text = session.ToString();
                Adresstxt.Text = address;
                RegisteratioNotxt.Text = reg;
            }
        }
    }
}
