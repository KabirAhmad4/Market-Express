﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUDA
{
    public partial class Main_fORM : Form
    {
        public Main_fORM()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Form a = new View_Students();
            a.Show();

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Form b = new View_Course();
            b.Show();


        }

        private void label4_Click(object sender, EventArgs e)
        {
            Form c = new View_Enrollments();
            c.Show();

        }

        private void label5_Click(object sender, EventArgs e)
        {
            Form d = new Attendance();
            d.Show();
        }
    }
}
